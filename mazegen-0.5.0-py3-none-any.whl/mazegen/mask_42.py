def make_p42_mask(maze):
    cx = maze.width // 2
    cy = maze.height // 2

    blocked_offsets = {
        (-3, -2),
        (-1, -2),
        (1, -2),
        (2, -2),
        (3, -2),
        (-3, -1),
        (-1, -1),
        (3, -1),
        (-3, 0),
        (-2, 0),
        (-1, 0),
        (1, 0),
        (2, 0),
        (3, 0),
        (-1, 1),
        (1, 1),
        (-1, 2),
        (1, 2),
        (2, 2),
        (3, 2),
    }

    blocked = set()

    for ox, oy in blocked_offsets:
        x = cx + ox
        y = cy + oy
        if 0 <= x < maze.width and 0 <= y < maze.height:
            blocked.add((y, x))  # (row, col)

    return blocked
